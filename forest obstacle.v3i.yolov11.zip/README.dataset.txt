# forest obstacle > 2024-01-13 1:32am
https://universe.roboflow.com/project-mrvr7/forest-obstacle

Provided by a Roboflow user
License: CC BY 4.0

